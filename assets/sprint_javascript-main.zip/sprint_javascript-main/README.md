# sprint_javascript

Na aula de hoje, os alunos farão um exercício passo a passo junto com o professor com o intuito de se aprofundar em conceitos como innerHTML e getElements. Além de manipular o estilo de elementos através do CSS com JavaScript.

