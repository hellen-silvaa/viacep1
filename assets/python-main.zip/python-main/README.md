# python
python Este repositório é destinado aos projetos da disciplina de "Computational Thinking with Python".

aula 00 - introdução 
.
aula 01 - comparadores
.
aula 02 -
.
