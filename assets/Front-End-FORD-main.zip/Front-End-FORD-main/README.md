# Front-End-FORD

# Projeto FIFA World Cup

https://65259ef1a3518a16ad6657c5--merry-pothos-04cf7c.netlify.app -> hospedagem do site na Netlify

# Projeto ViaCEP - Js

https://front-end-ford-two.vercel.app/

# Projeto Crud - Js

https://front-end-ford-94gb.vercel.app/

# Projeto Calculadora - Js

https://front-end-ford-coc3.vercel.app/
