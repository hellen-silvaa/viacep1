//Mapear para Nomes em Maiúsculas:
//Dado um array de nomes, crie um novo array contendo esses nomes em maiúsculas.

//const nomes = ['Alice', 'Bob', 'Charlie'];
// Saída esperada: ['ALICE', 'BOB', 'CHARLIE']

//----------------------------------------------------------

//filtrar números pares
//Crie uma função que aceite um array de números e retorne um novo array contendo apenas os números pares.
// const numeros = [1, 2, 3, 4, 5, 6];
// Saída esperada: [2, 4, 6]

//-----------------------------------------------------------

//Inverter um Array:
//Dado um array, crie uma função que retorne um novo array com os elementos na ordem inversa.
//const arrayOriginal = [1, 2, 3, 4, 5];
// Saída esperada: [5, 4, 3, 2, 1]
