//exemplo de notas

const nomeAluno = "Gustavo"
const nota1 = 9 
const nota2 = 4
const mediaAluno = (nota1 + nota2) / 2

(mediaAluno >= 7) ? console.log('aprovado') : console.log('reprovado');





// console.log(mediaAluno);

// if (mediaAluno >= 7) 
// {
//     console.log(`${nomeAluno} ficou com ${mediaAluno} de média final`);
// }
// else
// {
//     console.log(`${nomeAluno} ficou com ${mediaAluno} de média final`);
// }