//    camelCase
// var fabricanteCarro = "renault" 
// var modeloCarro = 'logan'
// var precoCarro = 16000
// var anoCarro = 2018

// fabricante: renault, modelo: logan, preco: 16000, ano: 2018

// console.log("fabricante: " + fabricanteCarro + ", modelo: " + modeloCarro + ", preco: " + precoCarro + ", ano: " + anoCarro)

// modeloCarro = "sandero"
// console.log(modeloCarro)

// modeloCarro = "clio"
// console.log(modeloCarro)









// trabalhar com variáveis, console.log

//utilizando padrão camelCase

//variavel(let, var, const) -> identificador -> dados
const carro = "4x4"
const fabricanteCarro = "renault"
const modeloCarro = "sandero"
const corCarro = "vermelha"
const anoCarro = 2010

//Primeira forma: Concatenação
console.log("carro: " + carro + ", fabricante: " + fabricanteCarro + ", modelo do carro: " + modeloCarro + ", cor do carro: " + corCarro + ", ano: " + anoCarro);

//Segunda forma: Interpolação
console.log(`meu carro: ${carro}, fabricante do carro: ${fabricanteCarro}, modelo carro: ${modeloCarro}, cor do carro: ${corCarro}, ano do carro: ${anoCarro}`);