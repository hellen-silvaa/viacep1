//fazer um exercício para calcular a área da circunferencia de um raio

// const PI = 3.14;
// const PI = Math.PI;
// let raio = 10;

//podemos utilizar um método nativo do js para calcular a área de PI
// let resultado = PI * (raio * raio)

// console.log(`O resultado da operação é: ${resultado} m2`);

//ou então....

// console.log(Math.PI);



// ******************** ATIVIDADE 01 ******************************

//Faça um programa que calcule a circurferência (área) de um círculo,
//utilizando alguns conceitos, tais como,
//variáveis, operadores aritméticos, concatenação, etc. 
// lembre-se da estrutura dos dados (Entrada de dados, Processamento e Saída de dados)
// tendo em mente que o raio da circunferência é de R = 16
























//entrada de dados

const raioCirculo = 16

//processamento de dados 
const resultadoRaio = Math.PI * (raioCirculo * raioCirculo)

//saida de dados
console.log(resultadoRaio.toFixed(2) + " cm²");







// const raio = 10
// const resultado = Math.PI * (raio * raio)

// console.log(`o retorno é de ${resultado.toFixed(2)}`);


















