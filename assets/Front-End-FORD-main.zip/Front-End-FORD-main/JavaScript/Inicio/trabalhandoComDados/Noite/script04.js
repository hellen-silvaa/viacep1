//variável constante não pode mudar dentro do nosso programa!

const a = 3

// a = 10
//ou 
a = a + 10

console.log(a);