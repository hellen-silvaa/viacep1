//tipos booleanos, só aceita apenas true and false ou então 0 e 1 
//let: conseguimos trocar o valor da variável

let isAtivo = false

console.log(isAtivo);

isAtivo = true 

console.log(isAtivo);