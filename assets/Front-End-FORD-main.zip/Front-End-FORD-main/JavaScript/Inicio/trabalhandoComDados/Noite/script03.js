//trabalhando com variáveis e vendo o tipo dessas variáveis

let idade = 21

console.log(typeof 21);
console.log(typeof idade);

//independente de ser ponto flutuante (float) ou não, o js sempre ve isso como um tipo number
let salario = 4.032
console.log(typeof salario);

//verificando o tipo de dado da variável estaChovendo
let estaChovendo = true
console.log(typeof estaChovendo);

console.log(typeof "teste");

