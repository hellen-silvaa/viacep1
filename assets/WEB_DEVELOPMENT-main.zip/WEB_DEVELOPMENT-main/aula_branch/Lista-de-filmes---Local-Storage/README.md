# Lista-de-filmes---Local-Storage
Projeto de lista de filmes salvando os favoritos na LocalStorage
