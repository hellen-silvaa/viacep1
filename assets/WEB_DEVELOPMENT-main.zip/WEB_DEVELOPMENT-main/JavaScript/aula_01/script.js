/* /* alert("Olá, mundo!")
prompt("Digite seu nome: ")
confirm("Você deseja sair?") 

console.log ("Mensaem no console") */

//Entrada
var nome = prompt("Digite seu nome: ")
var idade = prompt("Digite sua idade: ")
var profissao= prompt("Digite sua profissão: ")

//Saída
console.log("Olá " + nome + " você tem " + idade + " anos e sua profissão é " + profissao + " , seja bem-vindo(a)!")