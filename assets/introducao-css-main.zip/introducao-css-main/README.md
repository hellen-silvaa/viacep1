# Introdução ao CSS

O Cascading Style Sheets (CSS) é uma linguagem de folha de estilo usada para descrever a apresentação de um documento HTML. Com o CSS, é possível controlar o layout, as cores, as fontes e outros aspectos visuais de uma página web.

### Estrutura do Projeto




## Este é um arquivo com a extensão .md
### O Redme.md serve para mostrar informações do projeto a quem acessar o meu repositório

### A extensão .md significa que este arquivo é escrito em linguagem MarkDown que é muito parecida com o HTML

Demonstração e exercícios CSS externo - turma T4

![Imagem muito legal](./Imagem_legal.png)
<img src="./Imagem_legal.png" alt="Imagem muito legal">
.
